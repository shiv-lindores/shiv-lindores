const express = require('express');
const path = require('path');
const PORT = process.env.PORT || 3000;
let app = express();
app.use(express.static(__dirname));

const axios = require('axios');
const { render } = require('ejs');

app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: true }));

employeeData = [{ firstName: "John", lastName: "Doe", addressLine1: "10 Great Northern Street", addressLine2: "Lisburn Road", townCity: "Belfast", postcode: "BT9 7FW", salary: "15000", role: "Consultant", employeeNo: 40203046 },
{ firstName: "Jane", lastName: "Deer", addressLine1: "74 Glen Road", addressLine2: "", townCity: "Belfast", postcode: "BT11 8BH", salary: "25000", role: "Engineer", employeeNo: 39205863 },
{ firstName: "Mike", lastName: "Ehrmantraut", addressLine1: "100 York Street", addressLine2: "", townCity: "Belfast", postcode: "BT15 1WA", salary: "35000", role: "Senior DevOps Engineer", employeeNo: 20192653 },
{ firstName: "Jimmy", lastName: "McGill", addressLine1: "Apartment 3A", addressLine2: "42 Albert Place", townCity: "Ballymena", postcode: "BT43 6DY", salary: "40000", role: "Legal Consultant", employeeNo: 65940293 }
]

let userType = 0;

// home route
app.get('/', (req, res) => {

    let allemployees = employeeData;
    console.log(allemployees);
    res.render('viewallemployees', { employee: allemployees, userType: userType });

});

app.get('/sortByFirstName', (req, res) => {

    let sortbyfirstname = [];

    for (var i = 0; i < employeeData.length; i++) {
        sortbyfirstname[i] = employeeData[i];
    };

    sortbyfirstname.sort((a, b) => {
        let x = a.firstName.toLowerCase();
        let y = b.firstName.toLowerCase();
        if (x < y) { return -1; }
        if (x > y) { return 1; }
        return 0;
    });

    console.log(sortbyfirstname);
    res.render('viewallemployees', { employee: sortbyfirstname, userType });

});

app.get('/sortByLastName', (req, res) => {

    let sortbylastname = [];

    for (var i = 0; i < employeeData.length; i++) {
        sortbylastname[i] = employeeData[i];
    };

    sortbylastname.sort((a, b) => {
        let x = a.lastName.toLowerCase();
        let y = b.lastName.toLowerCase();
        if (x < y) { return -1; }
        if (x > y) { return 1; }
        return 0;
    });

    console.log(sortbylastname);
    res.render('viewallemployees', { employee: sortbylastname, userType });

});

app.get('/sortByRole', (req, res) => {

    let sortbyrole = [];

    for (var i = 0; i < employeeData.length; i++) {
        sortbyrole[i] = employeeData[i];
    };

    sortbyrole.sort((a, b) => {
        let x = a.role.toLowerCase();
        let y = b.role.toLowerCase();
        if (x < y) { return -1; }
        if (x > y) { return 1; }
        return 0;
    });

    console.log(sortbyrole);
    res.render('viewallemployees', { employee: sortbyrole, userType });

});

// home route
app.get('/addemployee', (req, res) => {

    res.render('addemployee', { employeeData, userType });

});

app.post('/addemployee', (req, res) => {

    // add info to employeeData from req body
    let firstName = req.body.firstName;
    let lastName = req.body.lastName;
    let addressLine1 = req.body.addressLine1;
    let addressLine2 = req.body.addressLine2;
    let townCity = req.body.townCity;
    let postcode = req.body.postcode;
    let salary = req.body.salary;
    let role = req.body.roleData;

    console.log(employeeData.length)

    let employeeNo

    if (!employeeData.length) {
        employeeNo = 1 
    } else {

        employeeNo = ((employeeData[employeeData.length - 1].employeeNo) + 1)

    }

    
    console.log(firstName)

    employeeData[employeeData.length] = { firstName: firstName, lastName, addressLine1, addressLine2, townCity, postcode, salary, role, employeeNo };

    console.log(employeeData)

    // redirect to 'view all employees' page?

    res.redirect('/');

});

app.get('/editemployee', (req, res) => {

    let userId = req.query.id;
    console.log(userId);

    let employee;

    for (var i = 0; i < employeeData.length; i++) {

        if (employeeData[i].employeeNo == userId) {
            employee = employeeData[i];
        }

    };

    res.render('editemployee', { employee, userType });

});

app.get('/switchtype', (req, res) => {

    if (userType == 0) {
        // switching from employee to admin
        userType = 1;
    } else if (userType == 1) {
        // switching from admin to employee
        userType = 0;
    }

    res.redirect('/');

});

app.post('/updateemployee', (req, res) => {

    let firstName = req.body.firstName;
    let lastName = req.body.lastName;
    let addressLine1 = req.body.addressLine1;
    let addressLine2 = req.body.addressLine2;
    let townCity = req.body.townCity;
    let postcode = req.body.postcode;
    let salary = req.body.salary;
    let role = req.body.role;
    let employeeNo = req.body.employeeNo;

    console.log(firstName)

    objIndex = employeeData.findIndex((obj => obj.employeeNo == employeeNo));

    employeeData[objIndex].firstName = firstName;
    employeeData[objIndex].lastName = lastName;
    employeeData[objIndex].addressLine1 = addressLine1;
    employeeData[objIndex].addressLine2 = addressLine2;
    employeeData[objIndex].townCity = townCity;
    employeeData[objIndex].postcode = postcode;
    employeeData[objIndex].salary = salary;
    employeeData[objIndex].role = role;
    employeeData[objIndex].employeeNo = employeeNo;

    console.log(employeeData);

    res.redirect('/');

});


app.get('/deleteemployee', (req, res) => {

    let userId = req.query.id;
    console.log(userId);

    let employeeNo = req.body.employeeNo;

    let index = employeeData.find(employee => employee.employeeNo === employeeNo);


    console.log(index)


    if (index !== -1) {

        let title = "Deletion Confirmation";
        let userMessage = "Are you sure you want to delete this record";
        let buttonName = "Delete";
        let linkName = "Cancel";
        res.render('userMessage', { employeeNo, title, userMessage, buttonName, linkName, userType });
    } else {
        res.redirect('/');
    }
});


app.post('/deleteemployee', (req, res) => {

    let userId = req.query.id;
    console.log(userId);

    let employeeNo = req.body.employeeNo;

    let index = employeeData.find(employee => employee.employeeNo === employeeNo);


    console.log(index)

    employeeData.splice(index, 1);

    res.redirect('/');

})




app.get('*', (req, res) => {
    res.status(404).render('error', { employee: employeeData, userType });
});


const server = app.listen(PORT, () => {
    console.log(`Website started on port ${server.address().port}`);
}); 