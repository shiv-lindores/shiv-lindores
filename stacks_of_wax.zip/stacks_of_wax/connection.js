const express = require('express');
const app = express();
const mysql  = require('mysql');

//better practice to use const here - let can be overwritten so this is better being constant
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'stacks_of_wax',
    port: '3306'
});

//previous code for error handling of connection
// db.connect((err)=> {
//     if(err){
//         throw err}
//         else {
//             console.log("connected");
//         }
    
// });

//cleaner outcome in console - nodemon doesn't crash use this for now 
db.connect((err)=> {
    if(err){
        return console.error('error:'+err.message);
    }
            console.log("connected to the MySQL server");    
});


app.set('view engine', 'ejs');

app.get('/',(req,res) => {
    res.send('<h2>My Account</h2>');
});



module.exports = db;