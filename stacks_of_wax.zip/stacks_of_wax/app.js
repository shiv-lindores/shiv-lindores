const express = require ('express');//won't work if express isn't downloaded through the console
const app = express();
const path = require('path');//builds path to your file
const connection = require("./connection.js");
const cookieParser = require('cookie-parser');
const bodyParser = require ('body-parser');
const sessions = require('express-session');
const mysql = require('mysql');
const { error } = require('console');
const oneHour = 1000 * 60 * 60 * 1;
const PORT = 3002;

app.set('view engine', 'ejs');//sits before routes - manages code a bit better
// need to have a folder called views - how to get to view of website

app.use(express.static(path.join(__dirname,'./public')));//static files to be used in this directory
app.use(express.urlencoded({extended: true}));
app.use(cookieParser());
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

//start to listen for request on the following routes
//req - from client/browser

app.get("/", (req, res) => {
    res.render('stacks_of_wax');
    //asking web server to listen for client
});

//lab 09 practice
app.use(sessions({
    secret: 'secretkey123',
    cookie: { maxAge: oneHour},
    saveUninitialized: true,
    resave: false
    }));

app.get('/dashboard', (req, res) => {
    // Check if user is logged in
    if (!req.session.authen) {
      return res.redirect('/signup');
    }
      res.render('dashboard');

  });
  

app.get('/collections', (req,res) => {

    console.log(req);

    let users_collections = `SELECT * FROM user_account_music_collection
                            INNER JOIN user_account 
                            ON user_account_music_collection.user_account_id=user_account.user_account_id
                            INNER JOIN music_collection 
                            ON user_account_music_collection.music_collection_id=music_collection.music_collection_id
                            WHERE user_account.user_account_id = ${req.session.userId}`;

    console.log(users_collections);

    connection.query(users_collections, (err, collectionsdata) =>{
        if (err) throw err;
        console.table(req);
        res.render('collections', {collectionsdata});
    });
});
    

app.get('/collection', (req,res) => {

    let collection = `SELECT * FROM music_collection_vinyl 
                        INNER JOIN vinyl 
                        ON music_collection_vinyl.vinyl_id=vinyl.vinyl_id 
                        INNER JOIN artist
                        ON vinyl.artist_id=artist.artist_id
                        INNER JOIN music_collection
                        ON music_collection_vinyl.music_collection_id=music_collection.music_collection_id
                        WHERE music_collection.user_account_id = ${req.session.userId}`;

    connection.query(collection, (err, collectiondata) =>{
        if (err) throw err;
        console.table(req);
        res.render('collection', {collectiondata});
    });
});

app.get('/login', (req,res) => {
    res.render('login');
});


app.use((req,res, next) =>{
    if (!req.session){
        return next(new Error('Session is not initialized'));
    }
    next();
});

app.post('/login', (req, res) => {

    console.log("Login request recieved");

    let checkuser = 'SELECT * FROM user_account WHERE username = ? AND password = ?';

    let username = req.body.username;
    let password = req.body.password;

    console.log(username);
    console.log(password);

    connection.query(checkuser, [username, password], (err, rows) => {

    if (err) throw err;

    let numRows = rows.length;
    console.log(numRows);

    if (numRows > 0) {
        console.log(rows);
        req.session.authen = true; 
        req.session.userId = rows[0].user_account_id;
        res.redirect('/dashboard');
    } else {
        console.log("before redirecting to dashboard");
        res.redirect('/signup');
        console.log("after redirecting to dashboard");
    }
});
});

app.get('/signup', (req, res)=> {
    res.render('signup');  
});
   
app.post('/signup', (req,res) => {

    let username = req.body.username;
    let password = req.body.password;
    let firstName = req.body.firstName;
    let lastName = req.body.lastName;
    let email = req.body.email;
    let DoB = req.body.DoB;

    console.log(username);
    console.log(password);
    console.log(firstName);
    console.log(lastName);
    console.log(email);
    console.log(DoB);

    let sqlinsert = `INSERT INTO user_account
                    (username, password, firstName, lastName, email, DoB, has_signed_up)
                    VALUES(?,?,?,?,?,?,?)`;

    console.log(req.body);

    connection.query(sqlinsert,
        [username, password, firstName, lastName,email,DoB, true], (err, dataobj) =>{
            if (err) throw err;
            res.redirect('/');
        });
});

app.get("/vinyls",(req,res) => {
    let readsql = `SELECT * FROM artist INNER JOIN 
                    vinyl ON 
                    artist.artist_id=vinyl.artist_id
                    ORDER BY artist_name`;
    connection.query(readsql,(err, rows)=>{
        if(err) throw err;
        let rowdata = rows;
        res.render('vinyls', {title: 'Our vinyls', rowdata});
    });
});

app.get("/row",(req,res) => {
    let vinyl_id = req.query.vinyl_id;
    let readsql = "SELECT * FROM vinyl WHERE vinyl_id = ?";
    connection.query(readsql, [vinyl_id], (err, rows)=>{
        if(err) throw err;
        console.log(rows);
        let vinyl = {
            vinyl_title: rows[0]['vinyl_title'],
            img_url: rows[0]['img_url'],
            release_year: rows[0]['release_year']
        };
        console.log(vinyl);
        res.render('collections', {vinyl});
    });
});

app.get('/admin/addVinyl', (req, res)=>{
    const artistQuery = `SELECT artist_id, artist_name FROM artist`;
    connection.query(artistQuery, (err, results) => {
        if (err) throw err;
        const artists = results;
        console.log(artists);
        res.render("addvinyl", {
            artist: artists
        });
    })
});

app.post('/admin/addVinyl', (req, res) =>{
    let vinyl_title = req.body.vinyl_title;
    let img_url = req.body.img_url;
    let sample_song_url = req.body.sample_song_url;
    let release_year = req.body.release_year;
    let artist_id = req.body.artist_id;
    let createsql = `INSERT INTO vinyl (vinyl_title, img_url, sample_song_url, release_year, artist_id) VALUES (?,?,?,?,?)`;
    connection.query(createsql,[vinyl_title, img_url, sample_song_url, release_year, artist_id], (err, rows)=>{
        if (err) throw err;
        res.render('vinylSuccessfulAdd');
    });  
});

app.get('/admin/addArtist', (req, res) => {
    res.render('addArtist');
});

  app.post('/admin/addArtist', (req, res) => {
    let artist_name = req.body.artist_name;
    console.log(artist_name);
    let insert_sql = "INSERT INTO artist (artist_name) VALUES (?)";
    connection.query(insert_sql, [artist_name], (err, result) => {
      if (err) throw err;
      res.redirect('/admin/artistSuccessfulAdd'); // redirect to the vinyl form
    });
});
  

app.get('/admin/artistSuccessfulAdd', (req, res) =>{
    res.render('artistSuccessfulAdd');
});

app.get('/admin/vinylSuccessfulAdd', (req, res) => {
    res.render('vinylSuccessfulAdd');
});
  

app.listen(PORT, ()=>{
    console.log(`server running on http://localhost:${PORT}`);
});